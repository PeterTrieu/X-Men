<?php $__env->startSection('content'); ?>

        <h1>Edit Submission</h1>
        <br>
        <?php echo Form::open(['action' => ['PostsController@update',$post->id],'method'=>'POST','enctype'=>'multipart/form-data']); ?>

            <div class="form-group">
                <?php echo e(Form::label('email','Email')); ?>

                <?php echo e(Form::text('email',$post->email,['class'=>'form-control','placeholder'=>'Email'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('description','Description')); ?>

                <?php echo e(Form::text('description',$post->description,['class'=>'form-control','placeholder'=>'Description'])); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('before_image','Before Image')); ?>

                 <?php echo e(Form::file('before_image')); ?>

            </div>
            <div class="form-group">
                <?php echo e(Form::label('before_image','After Image')); ?>

                <?php echo e(Form::file('after_image')); ?>

            </div>
            <?php echo e(Form::hidden('_method','PUT')); ?>

            <?php echo e(Form::submit('Submit',['class'=>'form-control'])); ?>

        <?php echo Form::close(); ?>

        <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>