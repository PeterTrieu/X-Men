<?php $__env->startSection('content'); ?>
    <div class="jumbotron text-center">
        <h1><?php echo e($title); ?></h1>
        <p><img src="https://nyoobserver.files.wordpress.com/2018/06/59542417c9e04.jpg?quality=80&w=970" alt="X-Men Logo" width='100%'></p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>