<?php if(auth()->guard()->guest()): ?>
        <?php $__env->startSection('content'); ?>
                <br>
                <h1>Welcome to the X-Mens</h1>
                <h2>Do you have what it takes to be a X-Men?</h2>
                <p>Please attach a before and after picture of yourself and as well as your email and a short description of your SUPERPOWER</p>
                <br>

                <?php echo Form::open(['action' => 'PostsController@store','method'=>'POST','enctype'=>'multipart/form-data']); ?>

                <div class="form-group">
                        <?php echo e(Form::label('email','Email')); ?>

                        <?php echo e(Form::text('email','',['class'=>'form-control','placeholder'=>'Email'])); ?>

                </div>
                <div class="form-group">
                        <?php echo e(Form::label('description','Description')); ?>

                        <?php echo e(Form::text('description','',['class'=>'form-control','placeholder'=>'Description'])); ?>

                </div>
                <div class="form-group">
                        <?php echo e(Form::label('before_image','Before Image')); ?>

                        <?php echo e(Form::file('before_image')); ?>

                </div>
                <div class="form-group">
                        <?php echo e(Form::label('before_image','After Image')); ?>

                        <?php echo e(Form::file('after_image')); ?>

                </div>
                <?php echo e(Form::submit('Submit',['class'=>'form-control'])); ?>

                <?php echo Form::close(); ?>

                <br>
        <?php $__env->stopSection(); ?>
<?php else: ?>
        <script>window.location = "/dashboard";</script>
<?php endif; ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>