<?php $__env->startSection('content'); ?>
        <h1><?php echo e($title); ?></h1>
        <h2>Do you have what it takes to be a X-Men?</h2>
        <p>Please attach a before and after picture of yourself and as well as your email and a short description of your SUPERPOWER</p>
        <br>
        <form>
            <div class='BPicture'>
                <p>Please attach your <b>BEFORE</b> Picture: <input type="file" name="bpic" accept="image/*" required> </p>
            </div>
            <div class='APicture'>
                <p>Please attach your <b>AFTER</b> Picture: <input type="file" name="apic" accept="image/*" required> </p>
            </div>
            <div class='Email'>
                <p>Please enter your email: <input type="email" name="email" required> </p>
            </div>
            <div class='Description'>
                <p>Please describe your super power: <input type="text" name="superpower" required> </p>
            </div>
            <div class='Submit'>
                <p><input type="submit" name="submit" value="SUBMIT"> </p>
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>