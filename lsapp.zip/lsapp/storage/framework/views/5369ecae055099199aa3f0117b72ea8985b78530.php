<?php $__env->startSection('content'); ?>
        <h1><?php echo e($title); ?></h1>
        <h2>Lets Login</h2>
        <br>
        <form>
            <div class='Username'>
                <p>Please enter your username: <input type="text" name="username" required> </p>
            </div>
            <div class='Password'>
                <p>Please enter your password: <input type="password" name="password" required> </p>
            </div>
            <div class='Submit'>
                <p><input name="submit" class="btn" type="submit" value="Submit"> </p>
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>