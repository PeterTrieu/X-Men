@extends('layouts.app')

@section('content')
    <div class="jumbotron text-center">
        <h1>{{$title}}</h1>
        <p><img src="https://nyoobserver.files.wordpress.com/2018/06/59542417c9e04.jpg?quality=80&w=970" alt="X-Men Logo" width='100%'></p>
    </div>
@endsection